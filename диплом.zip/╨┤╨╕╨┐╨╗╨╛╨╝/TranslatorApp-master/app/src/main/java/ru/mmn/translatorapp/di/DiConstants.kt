package ru.mmn.translatorapp.di

internal const val NAME_REMOTE = "Remote"
internal const val NAME_LOCAL = "Local"
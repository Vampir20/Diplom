package ru.mmn.translatorapp.utils

fun String.Companion.getEmptyString(): String = ""
package ru.mmn.noteapp;

public interface Observer {
    void updateNoteData (Note note);
}

package ru.mmn.noteapp;

public interface NoteSourceResponse {
    void initialized(NoteSource noteSource);
}

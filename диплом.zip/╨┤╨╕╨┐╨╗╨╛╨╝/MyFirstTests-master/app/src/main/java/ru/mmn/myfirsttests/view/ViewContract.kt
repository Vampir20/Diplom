package ru.mmn.myfirsttests.view

internal interface ViewContract {
}

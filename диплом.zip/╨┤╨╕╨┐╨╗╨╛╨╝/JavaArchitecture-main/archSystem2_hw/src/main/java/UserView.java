public class UserView {
    public void printUserInfo(int userId, String userName, String userPhoneNumber){
        System.out.println("User ID: " + userId);
        System.out.println("User Name: " + userName);
        System.out.println("User Phone Number: " + userPhoneNumber);
    }
}

public interface Blockrun extends Blockable{

    int getLength();
}

public interface Blockable {

}

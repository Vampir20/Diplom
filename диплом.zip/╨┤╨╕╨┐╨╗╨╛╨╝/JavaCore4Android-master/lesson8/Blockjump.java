public interface Blockjump extends Blockable{

    int getHeight();
}

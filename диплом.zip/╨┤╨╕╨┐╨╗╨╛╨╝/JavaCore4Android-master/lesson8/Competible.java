public interface Competible {

    int getMaxLength();
    int getMaxHeight();
    String getName();

    void run(Blockrun treadmill);
    void jump(Blockjump wall);

}

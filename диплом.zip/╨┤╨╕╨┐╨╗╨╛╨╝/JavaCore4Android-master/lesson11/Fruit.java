public class Fruit {

    float weight = 0;

}

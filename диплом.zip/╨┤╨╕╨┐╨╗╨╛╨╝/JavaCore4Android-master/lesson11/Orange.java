public class Orange extends Fruit{

    public Orange(){
        super.weight = 1.5f;
    }
}

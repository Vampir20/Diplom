public class Apple extends Fruit{

    public Apple(){
        super.weight = 1.0f;
    }
}

package ru.mmn.poplibslearnapp.view

interface BackButtonListener {
    fun backPressed(): Boolean
}
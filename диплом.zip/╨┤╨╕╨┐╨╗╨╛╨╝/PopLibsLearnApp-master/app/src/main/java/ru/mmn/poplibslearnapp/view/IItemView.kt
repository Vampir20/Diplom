package ru.mmn.poplibslearnapp.view

interface IItemView {
    var pos: Int
}
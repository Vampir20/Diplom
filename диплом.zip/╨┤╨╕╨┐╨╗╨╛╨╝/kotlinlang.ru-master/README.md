# kotlinlang.ru
Документация Kotlin на русском.

Для просмотра содержимого документации пройдите по адресу [kotlinlang.ru](https://kotlinlang.ru) (бывший [kotlin.su](http://kotlin.su))

Чтобы вносить изменения в файлы данного репозитория без задержки на одобрение pull-request, обратитесь в общий чат для получения доступа: https://t.me/KotlinLangRu
